import React, { useState } from "react";
import { Check, Copy, Share2, CornerUpLeft, ShieldCheck } from "lucide-react";
import { Game } from "../types";
import { getTeamFlag } from "../lib/flags";

interface PixPaymentProps {
  userName: string;
  userPhone: string;
  game: Game;
  homePrediction: number;
  awayPrediction: number;
  firstGoalPrediction: string;
  pixKey: string;
  pixReceiver: string;
  onReset: () => void;
}

export default function PixPayment({
  userName,
  userPhone,
  game,
  homePrediction,
  awayPrediction,
  firstGoalPrediction,
  pixKey,
  pixReceiver,
  onReset,
}: PixPaymentProps) {
  const [copied, setCopied] = useState(false);
  const [messageCopied, setMessageCopied] = useState(false);
  const betValue = "R$ 10,00";

  // Formatar mensagem do WhatsApp e configurar ação do botão
  const handleWhatsAppClick = () => {
    const text = `Bolão WL
Nome: ${userName}
Fone: ${userPhone}
Jogo: ${game.homeTeam} x ${game.awayTeam}
Palpite: ${homePrediction} x ${awayPrediction}
Primeiro gol: ${firstGoalPrediction}`;

    try {
      navigator.clipboard.writeText(text);
      setMessageCopied(true);
      setTimeout(() => setMessageCopied(false), 4000);
    } catch (err) {
      console.warn("Nao foi possivel copiar a mensagem", err);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(pixKey);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Gerar um link de QR Code válido usando a API do QRServer para renderizar visualmente a chave PIX
  // Usar cores preto no branco de alta fidelidade como o QrCode fornecido
  const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=250x250&color=000000&bgcolor=ffffff&data=${encodeURIComponent(
    pixKey
  )}`;

  return (
    <div className="bg-[#111] border border-white/10 rounded-3xl p-6 shadow-2xl max-w-md mx-auto text-center space-y-6 animate-fade-in relative overflow-hidden">
      <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/5 blur-3xl pointer-events-none rounded-full" />
      
      <div className="flex flex-col items-center">
        <div className="w-16 h-16 bg-blue-500/10 border border-blue-500/20 rounded-full flex items-center justify-center mb-3 animate-zoom-in">
          <ShieldCheck className="w-9 h-9 text-blue-500" />
        </div>
        <h2 className="text-xl font-bold text-white tracking-tight">Palpite Registrado!</h2>
        <p className="text-[10px] text-blue-500 font-bold uppercase tracking-widest mt-1">
          PASSO FINAL: FAÇA O PAGAMENTO VIA PIX
        </p>
      </div>

      {/* Detalhes do palpite */}
      <div className="bg-[#050505]/60 rounded-2xl p-4 text-left border border-white/10 space-y-3 font-medium">
        <h4 className="text-[10px] font-bold text-white/40 uppercase tracking-widest border-b border-white/10 pb-1.5 font-black">
          Resumo do Seu Palpite
        </h4>
        <div className="grid grid-cols-2 gap-y-2 text-xs">
          <span className="text-white/40">Participante:</span>
          <span className="text-white font-extrabold text-right truncate">{userName}</span>

          <span className="text-white/40">Partida:</span>
          <span className="text-white font-extrabold text-right flex items-center justify-end gap-1 select-none">
            <span>{getTeamFlag(game.homeTeam)}</span>
            <span className="truncate max-w-[50px] inline-block">{game.homeTeam}</span>
            <span className="text-white/30 text-[10px]">x</span>
            <span>{getTeamFlag(game.awayTeam)}</span>
            <span className="truncate max-w-[50px] inline-block">{game.awayTeam}</span>
          </span>

          <span className="text-white/40">Data/Hora:</span>
          <span className="text-white/70 font-bold text-right text-[11px]">
            {game.date} às {game.time}
          </span>

          <span className="text-white/40">Placar:</span>
          <span className="text-blue-500 font-black text-right text-sm">
            {homePrediction} × {awayPrediction}
          </span>

          <span className="text-white/40">Primeiro Gol:</span>
          <span className="text-white font-bold text-right truncate flex items-center justify-end gap-1">
            {firstGoalPrediction !== "Ninguém" && <span>{getTeamFlag(firstGoalPrediction)}</span>}
            <span>{firstGoalPrediction}</span>
          </span>

          <span className="text-white/40">Taxa do Palpite:</span>
          <span className="text-yellow-500 font-black text-right text-sm">{betValue}</span>
        </div>
      </div>

      {/* QR Code */}
      <div className="flex flex-col items-center space-y-4 bg-[#050505] p-5 rounded-2xl border border-white/10 animate-fade-in">
        {/* Mensagem Solicitada de Pagamento */}
        <div className="text-center space-y-0.5 border-b border-white/5 pb-3 w-full">
          <p className="text-xs font-black text-white/95 uppercase tracking-wider flex items-center justify-center gap-1.5 leading-none">
            <span>💸</span> Pagamento via PIX
          </p>
          <p className="text-lg font-black text-yellow-500 tracking-tight leading-none mt-1">
            R$ 10,00
          </p>
        </div>

        <div className="bg-white p-2.5 rounded-2xl shadow-xl shadow-black/40 border border-white/10">
          <img
            src={qrCodeUrl}
            alt="QR Code Pix"
            className="w-44 h-44 block rounded-lg"
            referrerPolicy="no-referrer"
          />
        </div>
        <div className="text-center space-y-0.5 pt-1">
          <p className="text-[9px] text-white/40 uppercase tracking-widest font-bold">Favorecido:</p>
          <p className="text-xs font-bold text-white/90">{pixReceiver}</p>
        </div>
      </div>

      {/* Chave Pix Copiar e Colar */}
      <div className="space-y-1.5">
        <label className="text-[9px] font-bold text-white/40 uppercase block tracking-widest text-left">
          Chave PIX
        </label>
        <div className="flex gap-2 bg-[#050505] border border-white/10 rounded-xl p-2.5 items-center justify-between">
          <span className="text-xs font-mono text-white/80 truncate select-all">{pixKey}</span>
          <button
            onClick={handleCopy}
            className="flex items-center gap-1.5 bg-blue-600 hover:bg-blue-500 transition-all duration-150 text-white rounded-lg px-3 py-1.5 text-[10px] font-black uppercase tracking-wider cursor-pointer shrink-0"
          >
            {copied ? (
              <>
                <Check className="w-3 h-3" />
                Copiado
              </>
            ) : (
              <>
                <Copy className="w-3 h-3" />
                Copiar
              </>
            )}
          </button>
        </div>
      </div>

      {/* Ações */}
      <div className="space-y-4 border-t border-white/10 pt-4">
        <a
          href="https://chat.whatsapp.com/DGLt6l0RCRJ1ZeH2TVafvu"
          target="_blank"
          rel="noopener noreferrer"
          onClick={handleWhatsAppClick}
          className="flex items-center justify-center gap-2 w-full bg-blue-600 hover:bg-blue-500 text-white font-black py-4 rounded-2xl transition-all shadow-[0_0_20px_rgba(37,99,235,0.3)] uppercase tracking-widest text-xs cursor-pointer"
        >
          <Share2 className="w-4 h-4 text-white" />
          {messageCopied ? "Palpite Copiado! Abrindo Grupo..." : "Copiar Palpite & Ir para o Grupo"}
        </a>

        {messageCopied ? (
          <p className="text-[10px] text-blue-400 font-bold tracking-wide animate-pulse">
            📋 Palpite copiado! Ao abrir o grupo, basta colar (Ctrl+V ou pressionar e colar).
          </p>
        ) : (
          <p className="text-[9px] text-white/30 font-semibold tracking-wide">
            Clique acima para copiar o palpite formatado e abrir o grupo de WhatsApp.
          </p>
        )}

        <button
          onClick={onReset}
          className="flex items-center justify-center gap-1.5 text-[10px] text-white/40 hover:text-white/80 transition uppercase tracking-wider font-bold py-1.5 mx-auto cursor-pointer"
        >
          <CornerUpLeft className="w-3.5 h-3.5" />
          Voltar e enviar outro palpite
        </button>
      </div>
    </div>
  );
}

